/* 标签条 preload */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('chromeApi', {
  cmd: function (cmd, payload) {
    try { ipcRenderer.send('chrome-cmd', Object.assign({ cmd: cmd }, payload || {})); } catch (e) { }
  },
  onState: function (cb) { ipcRenderer.on('chrome-state', function (e, state) { try { cb(state); } catch (err) { } }); }
});
