/* 直播助手 Mac 版 — Electron 主进程（移植自 Main.cs） */
const { app, BrowserWindow, WebContentsView, ipcMain, globalShortcut, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

const HOME = 'https://buyin.jinritemai.com/dashboard/live/control';
const CHROME_H = 44;              // 顶部工具栏高度
const DEFAULT_HOTKEYS = { 1: 'F1', 2: 'F2', 3: 'F3', 4: 'F9', 5: 'F5', 6: 'F6', 7: 'F7', 8: 'F8', 9: 'F10' };
const SAVE_WHITELIST = ['settings.json', 'products.json'];

let win = null;          // 主窗口
let chromeView = null;   // 顶部标签条
let tabs = [];           // [{ id, view, title, url }]，tabs[0] 固定为控制台
let panelWin = null;     // 助手面板窗口
let loggedIn = false;
let tabSeq = 0;
let activeId = null;
let injectJs = '';
let hotkeys = Object.assign({}, DEFAULT_HOTKEYS);

/* ---------- 工具 ---------- */
function dataFile(name) { return path.join(app.getPath('userData'), name); }
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(dataFile(file), 'utf8')); } catch (e) { return fallback; }
}
let lastStatus = '';
function setStatus(text) {
  lastStatus = String(text || '');
  pushChromeState();
}
function esc(s) { return String(s == null ? '' : s).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, '\\n'); }

/* ---------- 面板消息 ---------- */
function sendToPanel(obj) {
  if (panelWin && !panelWin.webContents.isDestroyed()) {
    panelWin.webContents.executeJavaScript('window.onHostMessage && window.onHostMessage(' + JSON.stringify(obj) + ')', true).catch(() => { });
  }
}

/* ---------- 标签条状态推送 ---------- */
function pushChromeState(statusText) {
  if (!chromeView || chromeView.webContents.isDestroyed()) return;
  const state = {
    tabs: tabs.map(t => ({ id: t.id, title: t.title || '新建标签', active: false, first: t.id === tabs[0].id })),
    activeId: activeTab() ? activeTab().id : null,
    loggedIn: loggedIn
  };
  const cur = activeTab();
  state.url = cur ? (cur.url || '') : '';
  state.status = statusText || lastStatus;
  chromeView.webContents.send('chrome-state', state);
}
function activeTab() {
  if (!tabs.length) return null;
  return tabs.find(t => t.view.visible) || tabs[0];
}

/* ---------- 登录检测（第一个标签页） ---------- */
const DETECT_JS = `(function(){
  var url = location.href;
  var onDash = /buyin\\.jinritemai\\.com\\/dashboard/.test(url);
  var hasPw = !!document.querySelector('input[type="password"]');
  var loginCls = false;
  try { loginCls = !!document.querySelector('[class*="login" i],[class*="Login"]'); } catch(e){}
  var phone = !!document.querySelector('input[type="tel"],input[placeholder*="手机"]');
  return { logged: !!(onDash && !hasPw && !loginCls && !phone), url: url };
})()`;

function handleLoginState(res) {
  if (!res) return;
  const was = loggedIn;
  loggedIn = !!res.logged;
  if (loggedIn && !was) {
    const t0 = tabs[0];
    if (t0 && t0.url && t0.url.indexOf('buyin.jinritemai.com/dashboard') < 0) {
      t0.view.webContents.loadURL(HOME).catch(() => { });
      setStatus('已登录，正在跳转控制台首页，新标签页已开启');
    } else {
      setStatus('已登录，新标签页功能已开启');
    }
    pushChromeState();
  } else if (!loggedIn && was) {
    setStatus('登录态丢失，新标签页已锁定');
    pushChromeState();
  }
}

/* ---------- 标签页管理 ---------- */
function makeTabPreload() { return path.join(__dirname, 'preload-tab.js'); }

function addTab(url, opts) {
  opts = opts || {};
  /* 登录门控：已有多于一个标签（说明控制台已建立）且未登录 → 拒绝 */
  if (!opts.force && tabs.length >= 1 && !loggedIn) {
    setStatus('请先登录百应账号后再打开新标签页');
    pushChromeState();
    return null;
  }
  tabSeq++;
  const view = new WebContentsView({
    webPreferences: {
      preload: makeTabPreload(),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  const tab = { id: tabSeq, view: view, title: '新建标签', url: url || 'about:blank', first: tabs.length === 0 };
  tabs.push(tab);

  const wc = view.webContents;
  wc.setWindowOpenHandler((details) => {
    /* 弹出窗口：未登录 → 强制第一个标签页跳转（达人登录场景）；已登录 → 开新标签页 */
    const u = details.url || '';
    if (!loggedIn) {
      if (/^https?:/i.test(u)) {
        tabs[0].view.webContents.loadURL(u).catch(() => { });
        setStatus('正在跳转登录页');
      }
      return { action: 'deny' };
    }
    if (/^https?:/i.test(u) || u === 'about:blank') addTab(u || 'about:blank');
    return { action: 'deny' };
  });

  wc.on('page-title-updated', (e, title) => { tab.title = (title || '').slice(0, 14) || '新建标签'; pushChromeState(); });
  wc.on('did-navigate', (e, url) => { tab.url = url; if (isActive(tab)) pushChromeState(); });
  wc.on('did-navigate-in-page', (e, url) => { tab.url = url; if (isActive(tab)) pushChromeState(); });

  wc.on('did-finish-load', () => {
    if (tab.first) {
      /* 注入助手脚本 + 登录检测 */
      if (injectJs) wc.executeJavaScript(injectJs, true).catch(() => { });
      wc.executeJavaScript(DETECT_JS, true).then(handleLoginState).catch(() => { });
    }
  });

  wc.on('render-process-gone', (e, details) => {
    setStatus('标签页异常退出: ' + (details.reason || ''));
  });

  view.setBounds(contentBounds());
  win.contentView.addChildView(view);
  switchTab(tab.id);
  view.webContents.loadURL(tab.url).catch(() => { });
  return tab;
}

function isActive(tab) { const a = activeTab(); return a && a.id === tab.id; }

function switchTab(id) {
  const t = tabs.find(x => x.id === id);
  if (!t) return;
  activeId = id;
  tabs.forEach(x => x.view.setVisible(x.id === id));
  layoutBounds();
  pushChromeState();
}

function closeTab(id) {
  const idx = tabs.findIndex(x => x.id === id);
  if (idx < 0) return;
  if (idx === 0) { setStatus('第一个标签页是控制台连接页，不能关闭'); pushChromeState(); return; }
  const t = tabs[idx];
  try { t.view.webContents.close(); } catch (e) { }
  win.contentView.removeChildView(t.view);
  tabs.splice(idx, 1);
  switchTab(tabs[Math.max(0, idx - 1)].id);
}

function contentBounds() {
  const [w, h] = win.getContentSize();
  return { x: 0, y: CHROME_H, width: Math.max(50, w), height: Math.max(50, h - CHROME_H) };
}
function layoutBounds() {
  tabs.forEach(t => t.view.setBounds(contentBounds()));
  if (chromeView) chromeView.setBounds({ x: 0, y: 0, width: win.getContentSize()[0], height: CHROME_H });
}

/* ---------- 全局热键 ---------- */
function toAccelerator(key) {
  const k = String(key || '').trim();
  if (/^F([1-9]|1[0-2])$/i.test(k)) return k.toUpperCase();
  const nm = k.match(/^Num([0-9])$/i); if (nm) return 'num' + nm[1];
  if (/^Space$/i.test(k)) return 'Space';
  if (/^(Home|End|PageUp|PageDown|Insert|Delete)$/i.test(k)) return k.toLowerCase().replace(/^./, c => c.toUpperCase()).replace('pageup', 'PageUp').replace('pagedown', 'PageDown');
  if (/^[A-Z0-9]$/i.test(k)) return k.toUpperCase();
  return null;
}
function registerHotkeys(map) {
  try { globalShortcut.unregisterAll(); } catch (e) { }
  hotkeys = Object.assign({}, DEFAULT_HOTKEYS, map || {});
  let okCount = 0, fail = [];
  for (const id in hotkeys) {
    const acc = toAccelerator(hotkeys[id]);
    if (!acc) { fail.push(hotkeys[id]); continue; }
    const aid = id;
    try {
      const ok = globalShortcut.register(acc, () => { sendToPanel({ type: 'hotkey', action: parseInt(aid, 10) }); });
      if (ok) okCount++; else fail.push(acc);
    } catch (e) { fail.push(acc); }
  }
  if (fail.length) setStatus('热键注册失败: ' + fail.join(',') + '（可能被其他软件占用）');
  else setStatus('热键注册成功（' + okCount + ' 个）');
}

/* ---------- 面板窗口 ---------- */
function createPanel() {
  panelWin = new BrowserWindow({
    width: 400, height: 780,
    x: (() => { try { const b = win.getBounds(); return b.x + b.width + 8; } catch (e) { return 100; } })(),
    y: (() => { try { return win.getBounds().y; } catch (e) { return 100; } })(),
    title: '直播助手面板',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload-panel.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  panelWin.setAlwaysOnTop(true, 'screen-saver');
  panelWin.loadFile('assistant.html');

  panelWin.webContents.on('did-finish-load', () => {
    /* 推送初始数据（对应原 Main.cs 的 init） */
    const settings = readJson('settings.json', {});
    const products = readJson('products.json', []);
    const hk = settings.hotkeys || hotkeys;
    sendToPanel({ type: 'init', settings: settings, products: products, hotkeys: hk });
    registerHotkeys(hk);
  });

  panelWin.on('closed', () => { panelWin = null; });
}

/* ---------- 主窗口 ---------- */
function createMainWindow() {
  win = new BrowserWindow({
    width: 1280, height: 860,
    title: '直播助手',
    autoHideMenuBar: true,
    webPreferences: { sandbox: false }
  });

  /* 顶部标签条 */
  chromeView = new WebContentsView({
    webPreferences: {
      preload: path.join(__dirname, 'preload-chrome.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  chromeView.setBounds({ x: 0, y: 0, width: 1280, height: CHROME_H });
  win.contentView.addChildView(chromeView);
  chromeView.webContents.loadFile('chrome.html').then(() => pushChromeState());

  win.on('resize', layoutBounds);
  win.on('closed', () => { win = null; });

  /* 第一个标签页（控制台），force 绕过登录门控 */
  addTab(HOME, { force: true });
}

/* ---------- IPC ---------- */
ipcMain.on('tab-msg', (e, obj) => {
  /* 控制台页 → 面板（rap-ready / live-end / live-state / sync-products / diag-report / viewer-chat ...） */
  if (!obj || typeof obj !== 'object') return;
  if (obj.type === 'login-state') { handleLoginState(obj); return; }   // 登录态由宿主处理
  if (obj.type === 'live-end') setStatus('检测到直播已结束，自动任务已停止');
  sendToPanel(obj);
});

ipcMain.on('panel-msg', (e, obj) => {
  if (!obj || typeof obj !== 'object') return;
  const t0 = tabs[0];
  switch (obj.type) {
    case 'rap':
      /* 转发到控制台页执行（含 CoreWebView2 判空保护，等价原 Bug1 修复） */
      if (t0 && !t0.view.webContents.isDestroyed()) {
        t0.view.webContents.executeJavaScript('window.__rapDispatch && window.__rapDispatch(' + JSON.stringify(obj) + ')', true).catch(() => { });
      } else {
        setStatus('控制台页面尚未就绪，请稍候');
      }
      break;
    case 'nav':
      if (t0 && /^https?:/i.test(String(obj.url || ''))) t0.view.webContents.loadURL(obj.url).catch(() => { });
      break;
    case 'set-topmost':
      if (panelWin) panelWin.setAlwaysOnTop(!!obj.value, 'screen-saver');
      break;
    case 'save-file':
      if (SAVE_WHITELIST.indexOf(obj.file) >= 0) {
        try { fs.writeFileSync(dataFile(obj.file), String(obj.content || ''), 'utf8'); } catch (err) { }
      }
      break;
    case 'hotkeys':
      registerHotkeys(obj.map);
      break;
    case 'status':
      setStatus(String(obj.text || '').slice(0, 120));
      break;
  }
});

ipcMain.on('chrome-cmd', (e, obj) => {
  if (!obj || typeof obj !== 'object') return;
  const cur = activeTab();
  switch (obj.cmd) {
    case 'new-tab': addTab('about:blank'); break;
    case 'close-tab': closeTab(parseInt(obj.id, 10)); break;
    case 'switch-tab': switchTab(parseInt(obj.id, 10)); break;
    case 'back': if (cur) cur.view.webContents.navigationHistory.goBack(); break;
    case 'forward': if (cur) cur.view.webContents.navigationHistory.goForward(); break;
    case 'reload': if (cur) cur.view.webContents.reload(); break;
    case 'go':
      if (cur && /^https?:\/\//i.test(String(obj.url || ''))) cur.view.webContents.loadURL(obj.url).catch(() => { });
      break;
    case 'console': if (tabs[0]) switchTab(tabs[0].id); break;
  }
});

/* ---------- 旧配置迁移（Windows 上从原版 %LocalAppData%\LiveAssistant 拷过来） ---------- */
function migrateOldData() {
  try {
    const oldDir = path.join(app.getPath('appData'), '..', 'Local', 'LiveAssistant');
    for (const f of SAVE_WHITELIST) {
      const nf = dataFile(f);
      if (!fs.existsSync(nf)) {
        const of = path.join(oldDir, f);
        if (fs.existsSync(of)) fs.copyFileSync(of, nf);
      }
    }
  } catch (e) { }
}

/* ---------- 启动 ---------- */
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('in-process-gpu');   /* GPU 并入主进程，远程桌面/虚拟机/沙箱环境不再因 GPU 子进程崩溃 */
app.disableHardwareAcceleration();                /* DOM 自动化不需要 GPU，关闭硬件加速提高兼容性 */
app.whenReady().then(() => {
  injectJs = fs.readFileSync(path.join(__dirname, 'inject.js'), 'utf8');
  migrateOldData();
  createMainWindow();
  createPanel();
  setStatus('请先在第一个标签页登录百应');
});

app.on('window-all-closed', () => { app.quit(); });
app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch (e) { } });
