/* 面板 preload：面板 → 宿主（宿主 → 面板走 executeJavaScript(onHostMessage)） */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('panelApi', {
  post: function (obj) { try { ipcRenderer.send('panel-msg', obj); } catch (e) { } }
});
