# 直播助手 Mac 版（Electron）

Windows 版 LiveAssistant 的 macOS（Intel 处理器）移植版，方案 A（Electron）。

## 与 Windows 版的关系

| 文件 | 来源 | 说明 |
|---|---|---|
| `inject.js` | 复用（仅改 send 桥） | 页面自动化逻辑 100% 保留，优先走 Electron 桥，也兼容原 WebView2 |
| `assistant.html` | 复用（仅改 post 桥） | 面板全部功能保留，宿主调用 `onHostMessage()` 机制不变 |
| `main.js` | 新写 | 等价原 `Main.cs`：多标签、登录门控、热键、消息路由、文件白名单 |
| `chrome.html` | 新写 | 顶部标签条（原 WinForms TabControl + 工具栏） |
| `preload-*.js` | 新写 | contextBridge 安全桥 |

## 目录运行（Windows 上开发调试）

```
npm install
npm start
```

功能与 Windows 版一致：登录门控、预启动、自动弹窗/发评、公屏自动回复、商品报链接号、F1–F10/小键盘热键。

## 打包 macOS Intel 版

**方式一：GitHub Actions（推荐，产物可直接用）**
1. 把本目录推到 GitHub 仓库（公开仓库免费）
2. Actions 页面手动触发 `Build Mac (Intel)`，或推一个 `v*` tag
3. 下载 artifact `LiveAssistant-mac-x64.zip`，解压得到 `LiveAssistant-darwin-x64/LiveAssistant.app`

**方式二：本机打包（Windows 上直接打，但不推荐）**
```
npm run pack:mac
```
⚠️ Windows 上打 mac 包因 symlink 限制产物很可能无法运行，仅作预览；正式分发用方式一。

## 未签名说明

没有 Apple 开发者账号（$99/年）时，mac 首次打开会提示"无法验证开发者"：
右键 `LiveAssistant.app` → 打开 → 再点"打开"即可（只需一次）。如果要发给其他达人用，建议注册开发者账号后签名公证。

## 数据目录

- Windows 调试：`%AppData%\liveassistant-mac\`（settings.json / products.json）
- 首次启动会自动从原版 `%LocalAppData%\LiveAssistant\` 迁移配置和商品数据（如存在）
- macOS：`~/Library/Application Support/liveassistant-mac/`
