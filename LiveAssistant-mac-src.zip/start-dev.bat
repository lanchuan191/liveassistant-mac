@echo off
rem Windows 上开发调试启动（需先 npm install）
set ELECTRON_RUN_AS_NODE=
cd /d "%~dp0"
"C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2-3\npm.cmd" start
