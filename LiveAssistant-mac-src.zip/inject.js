/* =====================================================================
 * 直播助手 - 官方控制台页面自动化脚本 (inject.js)  v4
 * 按 2026-08-12 真实诊断 DOM 精确校准（百应中控台，auxo 组件库）。
 *
 * 真实结构要点：
 *  - 商品行：div.auxo-row，行内信息锚点 [class*="itemInfo"]
 *  - 商品名：[class*="titleLink"]；无库存等状态：[class*="goodsImgStatus"]
 *  - 行内按钮（真实 <button>）：讲解 / 预热 / 库存管理 / 下架 / 删除 /
 *    创建达人券 / 设置搭配 / 设置分组 等
 *  - 发评输入框：textarea[placeholder*="发评"]（enter 一键发送）
 *
 * ★ 若官方再次改版：面板“设置”页“运行诊断”，把结果发回开发者校准。
 * ===================================================================== */
(function () {
  'use strict';

  /* 防重入：页面多次导航会重复注入本脚本，旧的定时器/Observer 无法清理，
   * 直接跳过重注入并补发 rap-ready，避免同步定时器和评论监听叠加。 */
  if (window.__rap) { try { send('rap-ready', { installed: true }); } catch (e) { } return; }

  var CFG = {
    sel: {
      rowAnchor: '[class*="itemInfo"]',          /* 行内信息块，向上找 auxo-row */
      rowBox: '.auxo-row',
      rowTitle: '[class*="titleLink"]',
      rowStatus: '[class*="goodsImgStatus"]',
      commentBoxes: [
        'textarea[placeholder*="发评"]',
        'textarea[placeholder*="回复观众"]',
        'textarea[placeholder*="消息"]',
        'textarea[placeholder*="话术"]',
        'textarea',
        '[contenteditable="true"]'
      ],
      sendBtnTexts: ['发送', '发布'],
      popBtnTexts: ['讲解', '弹窗'],
      stockBtnTexts: ['库存管理', '改库存', '库存'],
      confirmBtnTexts: ['确定', '确认', '保存', '提交'],
      dialogs: [
        '[role="dialog"]',
        '[class*="modal" i]',
        '[class*="dialog" i]',
        '[class*="drawer" i]',
        '[class*="popover" i]',
        '[class*="popup" i]'
      ],
      menus: [
        '[role="menu"]',
        '[class*="menu" i]',
        '[class*="dropdown" i]',
        '[class*="popover" i]'
      ],
      commentLists: [
        '[class*="comment" i] [class*="list" i]',
        '[class*="chat" i] [class*="list" i]',
        '[class*="commentList" i]',
        '[class*="chatList" i]'
      ]
    }
  };

  function send(type, extra) {
    try {
      var m = { type: type };
      if (extra) for (var k in extra) m[k] = extra[k];
      if (window.rapBridge) { window.rapBridge.send(m); return; }          /* Electron 桥 */
      if (window.chrome && chrome.webview) { chrome.webview.postMessage(m); return; }  /* WebView2（原版兼容） */
    } catch (e) { }
  }

  function q(sel) { try { return document.querySelector(sel); } catch (e) { return null; } }
  function qa(sel) { try { return Array.prototype.slice.call(document.querySelectorAll(sel)); } catch (e) { return []; } }
  function visible(el) { return !!el && el.offsetWidth > 0 && el.offsetHeight > 0; }

  /* 百应中控台大量内容（直播状态、结束直播按钮、评论输入框）放在 iframe 内，
   * 只查顶层 document 会漏掉。这里递归收集当前页及所有可访问的 iframe 文档。 */
  function allRootDocuments(maxDepth) {
    maxDepth = maxDepth || 2;
    var docs = [];
    function collect(doc, depth) {
      if (!doc) return;
      docs.push(doc);
      if (depth <= 0) return;
      try {
        var frames = doc.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
          var fd = null;
          try { fd = frames[i].contentDocument || (frames[i].contentWindow && frames[i].contentWindow.document); } catch (e) { continue; }
          collect(fd, depth - 1);
        }
      } catch (e) { }
    }
    collect(document, maxDepth);
    return docs;
  }
  function qaAll(sel, maxDepth) {
    var docs = allRootDocuments(maxDepth);
    var out = [];
    for (var i = 0; i < docs.length; i++) {
      try { out = out.concat(Array.prototype.slice.call(docs[i].querySelectorAll(sel))); } catch (e) { }
    }
    return out;
  }

  function setNativeValue(el, value) {
    try {
      if (el.isContentEditable) { el.focus(); el.innerText = value; el.dispatchEvent(new Event('input', { bubbles: true })); el.blur(); return; }
      var proto = (el instanceof HTMLTextAreaElement)
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      try { el.focus(); } catch (e3) { }
      if (desc && desc.set) desc.set.call(el, value); else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      try { el.blur(); } catch (e4) { }
    } catch (e) { try { el.value = value; } catch (e2) { } }
  }

  /* ================= 按文字找可点元素 ================= */
  function findTextEl(root, text, allowHidden) {
    var els = root.querySelectorAll('*');
    var best = null, bestHidden = null;
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var t = (el.textContent || '').trim();
      if (!t) continue;
      if (t === text || (t.length <= text.length + 4 && t.indexOf(text) === 0)) {
        if (visible(el)) { if (!best || el.children.length < best.children.length) best = el; }
        else if (!bestHidden || el.children.length < bestHidden.children.length) bestHidden = el;
      }
    }
    if (best) return best;
    return allowHidden ? bestHidden : null;
  }
  function clickButtonByText(root, text) {
    var btns = root.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
      var t = (btns[i].textContent || '').trim();
      if (t === text || (t.length <= text.length + 4 && t.indexOf(text) === 0)) { try { btns[i].click(); } catch (e) { } return true; }
    }
    return false;
  }
  function clickText(root, text) {
    if (clickButtonByText(root, text)) return true;
    var el = findTextEl(root, text, false) || findTextEl(root, text, true);
    if (el) {
      var b = el.closest ? el.closest('button') : null;
      try { (b || el).click(); } catch (e) { }
      return true;
    }
    return false;
  }
  function hasText(root, text) { return !!findTextEl(root, text, false); }

  function findMoreBtn(row) {
    var cands = row.querySelectorAll('button, span, div, i, svg');
    for (var i = 0; i < cands.length; i++) {
      var el = cands[i];
      var t = (el.textContent || '').trim();
      var aria = (el.getAttribute && (el.getAttribute('aria-label') || '')) || '';
      if (t === '...' || t === '…' || t === '更多' || aria.indexOf('更多') >= 0 || aria.indexOf('more') >= 0) return el;
    }
    return null;
  }
  function lastVisible(selList) {
    var list = [];
    for (var i = 0; i < selList.length; i++) {
      var els = qa(selList[i]);
      for (var j = 0; j < els.length; j++) if (visible(els[j])) list.push(els[j]);
    }
    return list.length ? list[list.length - 1] : null;
  }
  function rowAction(row, text) {
    if (!row) return { ok: false, msg: '行不存在' };
    if (clickText(row, text)) return { ok: true };
    var more = findMoreBtn(row);
    if (more) {
      try { more.click(); } catch (e) { }
      setTimeout(function () {
        var menu = lastVisible(CFG.sel.menus);
        if (menu && clickText(menu, text)) return;
        clickText(document, text);
      }, 450);
      return { ok: true, msg: 'via-more' };
    }
    return { ok: false, msg: '未找到:' + text };
  }

  /* ================= 发评 ================= */
  /* 判断输入框是否属于“给主播留言”消息框（自动发评禁止使用） */
  function isHostMessageBox(el) {
    try {
      var ph = '';
      if (el.getAttribute) ph = (el.getAttribute('placeholder') || '') + ' '
        + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '');
      if (/主播|留言/.test(ph)) return true;
      /* 向上找小范围容器，看是否带“给主播留言”标签 */
      var p = el.parentElement, hop = 0;
      while (p && hop < 5) {
        var t = (p.textContent || '').trim();
        if (t.length > 300) break;
        if (t && /给主播留言|主播留言/.test(t)) return true;
        p = p.parentElement; hop++;
      }
    } catch (e) { }
    return false;
  }
  function findCommentBox() {
    for (var i = 0; i < CFG.sel.commentBoxes.length; i++) {
      var els = qaAll(CFG.sel.commentBoxes[i], 2);
      for (var j = 0; j < els.length; j++) {
        var el = els[j];
        if (el && !el.disabled && visible(el) && !isHostMessageBox(el)) return el;
      }
    }
    return null;
  }
  function sendComment(text) {
    try {
      var box = findCommentBox();
      if (!box) return { ok: false, msg: '未找到评论输入框（已排除给主播留言框）' };
      box.focus();
      setNativeValue(box, text);
      /* 官方提示 enter 一键发送 */
      box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      box.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      box.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      /* 兜底：点发送按钮 */
      var scope = box.parentElement;
      for (var up = 0; up < 4 && scope; up++) {
        if (clickSendButton(scope)) return { ok: true };
        scope = scope.parentElement;
      }
      clickSendButton(document);
      return { ok: true };
    } catch (e) { return { ok: false, msg: String(e) }; }
  }
  function clickSendButton(scope) {
    for (var j = 0; j < CFG.sel.sendBtnTexts.length; j++) {
      if (clickText(scope, CFG.sel.sendBtnTexts[j])) return true;
    }
    return false;
  }

  /* ================= 商品行定位（精确） ================= */
  function countAnchors(root) { try { return root.querySelectorAll(CFG.sel.rowAnchor).length; } catch (e) { return 0; } }
  function getRows() {
    var items = qaAll('[class*="goodsItem"]', 2);
    if (items.length) return items.slice(0, 60);
    var rows = [];
    var anchors = qaAll(CFG.sel.rowAnchor, 2);
    for (var i = 0; i < anchors.length; i++) {
      var el = anchors[i], upper = null;
      for (var up = 0; up < 6 && el; up++) {
        if (el.classList && el.classList.contains('auxo-row')) { upper = el; break; }
        el = el.parentElement;
      }
      if (!upper) upper = anchors[i].closest ? anchors[i].closest(CFG.sel.rowBox) : null;
      if (!upper) continue;
      var row = upper;
      var par = upper.parentElement;
      if (par && countAnchors(par) === 1) row = par; /* 单品包装层，含动作按钮行 */
      if (rows.indexOf(row) < 0) rows.push(row);
    }
    if (rows.length) return rows.slice(0, 60);
    /* 兜底：商品图锚点 */
    var imgs = qaAll('img', 2);
    for (var n = 0; n < imgs.length; n++) {
      var img = imgs[n];
      if (!visible(img)) continue;
      var w = img.offsetWidth || img.width;
      if (w < 40 || w > 220) continue;
      var p = img.parentElement, r2 = null;
      for (var u2 = 0; u2 < 8 && p; u2++) {
        var tx = p.textContent || '';
        if (tx.indexOf('¥') >= 0 && tx.length < 900) { r2 = p; break; }
        p = p.parentElement;
      }
      if (r2 && rows.indexOf(r2) < 0) rows.push(r2);
    }
    return rows.slice(0, 60);
  }
  /* 行作用域：包装层本身，或 upper 行 + 相邻 lower 行 */
  function rowScopes(row) {
    var scopes = [row];
    if (row.classList && row.classList.contains('auxo-row')) {
      var sib = row.nextElementSibling;
      for (var i = 0; i < 2 && sib; i++) {
        if (sib.classList && sib.classList.contains('auxo-row') && countAnchors(sib) === 0) {
          scopes.push(sib);
          sib = sib.nextElementSibling;
        } else break;
      }
    }
    return scopes;
  }
  function scopesText(scopes) {
    var t = '';
    for (var i = 0; i < scopes.length; i++) t += (scopes[i].textContent || '') + ' ';
    return t.replace(/\s+/g, ' ');
  }
  function scopesQuery(scopes, sel) {
    var out = [];
    for (var i = 0; i < scopes.length; i++) {
      var els = scopes[i].querySelectorAll(sel);
      for (var j = 0; j < els.length; j++) out.push(els[j]);
    }
    return out;
  }
  function rowActionScopes(scopes, text) {
    for (var i = 0; i < scopes.length; i++) {
      var r = rowAction(scopes[i], text);
      if (r.ok) return r;
    }
    return { ok: false, msg: '未找到:' + text };
  }

  function parseWan(s) {
    if (!s) return 0;
    var m = parseFloat(s);
    if (isNaN(m)) return 0;
    return s.indexOf('万') >= 0 ? m * 10000 : m;
  }

  /* ================= 商品列表抓取（同步左侧按钮） ================= */
  function scrapeProducts() {
    var rows = getRows();
    var items = [];
    for (var i = 0; i < rows.length; i++) {
      try {
        var row = rows[i];
        var scopes = rowScopes(row);
        var txt = scopesText(scopes);
        var item = { i: i, name: '', id: '', price: 0, stock: 0, sold: 0, status: '', actions: [] };

        var titleEl = scopesQuery(scopes, CFG.sel.rowTitle)[0] || scopesQuery(scopes, '[class*="title-"]')[0];
        if (titleEl) item.name = (titleEl.textContent || '').trim().slice(0, 60);

        var stEl = scopesQuery(scopes, CFG.sel.rowStatus)[0];
        if (stEl) item.status = (stEl.textContent || '').trim();

        /* ID 优先取行内文字里的商品ID（与中控台悬停提示一致）；
         * data-rbd-draggable-id 是拖拽排序的内部ID，与商品ID是两套体系，只作兜底 */
        var idm = txt.match(/ID[:：\s]*(\d{10,20})/i) || txt.match(/\b(\d{15,20})\b/);
        item.id = idm ? idm[1] : '';
        if (!item.id) item.id = (row.getAttribute && (row.getAttribute('data-rbd-draggable-id') || '')) || '';

        var pm = txt.match(/¥\s*([\d.]+)/);
        if (pm) item.price = parseFloat(pm[1]);

        var sm = txt.match(/([\d.]+万?)\s*\/\s*([\d.]+万?)/);
        if (sm) { item.sold = parseWan(sm[1]); item.stock = parseWan(sm[2]); }

        /* 行内真实按钮 -> 同步到面板 */
        var btns = scopesQuery(scopes, 'button');
        var seen = {};
        for (var b = 0; b < btns.length; b++) {
          var bt = (btns[b].textContent || '').trim();
          if (bt && bt.length <= 8 && !seen[bt]) { seen[bt] = true; item.actions.push(bt); }
        }
        if (item.name || item.id || item.price) items.push(item);
      } catch (e) { }
    }
    return items;
  }

  var syncTimer = null;
  function setSync(on, intervalSec) {
    if (syncTimer) { clearInterval(syncTimer); syncTimer = null; }
    if (on) {
      var sec = Math.max(5, parseInt(intervalSec) || 15);
      var doIt = function () { send('sync-products', { items: scrapeProducts() }); };
      doIt();
      syncTimer = setInterval(doIt, sec * 1000);
    }
  }

  /* ================= 弹品（官方“讲解”即弹窗讲解） ================= */
  function popProduct(msg) {
    try {
      var rows = getRows();
      var target = -1;
      if (msg.id) {
        for (var r = 0; r < rows.length; r++) {
          if ((rows[r].textContent || '').indexOf(String(msg.id)) >= 0) { target = r; break; }
        }
      }
      if (target < 0 && typeof msg.index === 'number' && msg.index >= 0 && msg.index < rows.length) target = msg.index;
      if (target >= 0) {
        var scopes = rowScopes(rows[target]);
        var rowBtns = scopesQuery(scopes, 'button');
        for (var rb = 0; rb < rowBtns.length; rb++) {
          if ((rowBtns[rb].textContent || '').trim() === '取消讲解') { send('pop-skip', { index: target }); return { ok: true, msg: '该商品已在讲解中' }; }
        }
        for (var p = 0; p < CFG.sel.popBtnTexts.length; p++) {
          var res = rowActionScopes(scopes, CFG.sel.popBtnTexts[p]);
          if (res.ok) { send('pop-done', { index: target }); return res; }
        }
      }
      return { ok: false, msg: '未找到弹品按钮' };
    } catch (e) { return { ok: false, msg: String(e) }; }
  }

  function hasBtn(scopes, text) {
    var btns = scopesQuery(scopes, 'button');
    for (var i = 0; i < btns.length; i++) if ((btns[i].textContent || '').trim() === text) return true;
    return false;
  }
  function clickOnce(scopes) {
    if (hasBtn(scopes, '取消讲解')) return rowActionScopes(scopes, '取消讲解');
    for (var p = 0; p < CFG.sel.popBtnTexts.length; p++) {
      var r = rowActionScopes(scopes, CFG.sel.popBtnTexts[p]);
      if (r.ok) return r;
    }
    return { ok: false, msg: '未找到讲解按钮' };
  }
  /* 自动弹窗周期动作：initial 时按当前状态点1或2次，否则连点2次 */
  function popCycle(msg) {
    try {
      var rows = getRows();
      var target = -1;
      if (msg.id) {
        for (var r = 0; r < rows.length; r++) {
          if ((rows[r].textContent || '').indexOf(String(msg.id)) >= 0) { target = r; break; }
        }
      }
      if (target < 0 && typeof msg.index === 'number' && msg.index >= 0 && msg.index < rows.length) target = msg.index;
      if (target < 0) return { ok: false, msg: '行不存在' };
      var scopes = rowScopes(rows[target]);
      var clicks = msg.initial ? (hasBtn(scopes, '取消讲解') ? 2 : 1) : 2;
      clickOnce(scopes);
      if (clicks === 2) setTimeout(function () { clickOnce(scopes); }, 500);
      send('pop-done', { index: target });
      return { ok: true };
    } catch (e) { return { ok: false, msg: String(e) }; }
  }

  /* 预热确认：官方点“预热”后弹窗内点“直接预热” */
  function confirmPreheat() {
    var waited = 0;
    var poll = setInterval(function () {
      waited += 300;
      var btns = qa('button');
      for (var i = 0; i < btns.length; i++) {
        if (visible(btns[i]) && (btns[i].textContent || '').trim() === '直接预热') {
          clearInterval(poll);
          try { btns[i].click(); } catch (e) { }
          send('rap-log', { text: '已点击直接预热' });
          return;
        }
      }
      if (waited >= 2400) { clearInterval(poll); send('rap-log', { text: '未检测到直接预热按钮，请手动确认' }); }
    }, 300);
  }

  /* ================= 库存快捷修改 ================= */
  function collectNums(root) {
    var inps = root.querySelectorAll('input[type="number"], input[inputmode="numeric"], input[type="text"], [contenteditable="true"]');
    var nums = [];
    for (var n = 0; n < inps.length; n++) {
      var el = inps[n];
      if (!visible(el) || el.disabled || el.readOnly) continue;
      var ph = (el.getAttribute && (el.getAttribute('placeholder') || '')) || '';
      if (/名称|ID|搜索|关键|筛选/.test(ph)) continue;
      if (el.closest && (el.closest('[class*="indexWrapper"]') || el.closest('.auxo-sp-input'))) continue; /* 序号输入框 */
      var v = el.isContentEditable ? el.innerText : el.value;
      if (v === '' || /^[\d.]+$/.test(v)) nums.push(el);
    }
    return nums;
  }
  function collectNumsInScopes(scopes) {
    var out = [];
    for (var i = 0; i < scopes.length; i++) out = out.concat(collectNums(scopes[i]));
    return out;
  }

  function findStockDialog() {
    var btns = qa('button');
    var btn = null;
    for (var i = 0; i < btns.length; i++) {
      var t = (btns[i].textContent || '').trim();
      if (t === '批量填充' || t === '全部填充') { btn = btns[i]; break; }
    }
    if (!btn) return null;
    var el = btn;
    for (var up = 0; up < 8 && el; up++) {
      el = el.parentElement;
      if (el && el.querySelectorAll('input').length >= 1 && (el.textContent || '').length > 100) break;
    }
    return el;
  }

  function readSkuList(dlg) {
    var batch = dlg.querySelector('input[placeholder*="批量上架数量"]');
    var nums = collectNums(dlg);
    if (batch) nums = nums.filter(function (el) { return el !== batch; });
    var skus = [];
    for (var i = 0; i < nums.length; i++) {
      var el = nums[i];
      var box = el;
      for (var up = 0; up < 6 && box; up++) {
        if ((box.textContent || '').indexOf('¥') >= 0) break;
        box = box.parentElement;
      }
      var boxTxt = (box || el.parentElement).textContent || '';
      var yi = boxTxt.indexOf('¥');
      var nameTxt = (yi > 0 ? boxTxt.slice(0, yi) : boxTxt).replace(/\s+/g, ' ').trim().slice(0, 50);
      var mx = 0;
      var mMax = boxTxt.match(/¥\s*[\d,\.]+\s*([\d,\.]+)/); /* 专属价之后的第一个数字=剩余专属库存 */
      if (mMax) mx = parseFloat(String(mMax[1]).replace(/,/g, ''));
      if (!mx || isNaN(mx)) { var mR = boxTxt.match(/剩余专属库存\s*([\d,\.]+)/); if (mR) mx = parseFloat(String(mR[1]).replace(/,/g, '')); }
      if (!mx || isNaN(mx)) mx = parseFloat(el.max);
      skus.push({ name: nameTxt, stock: parseFloat(el.isContentEditable ? el.innerText : el.value) || 0, max: (isNaN(mx) ? 0 : mx) });
    }
    return skus;
  }

  function openStockDialog(scopes, cb) {
    var attempt = 0;
    function tryOpen() {
      attempt++;
      var res = null;
      for (var s = 0; s < CFG.sel.stockBtnTexts.length; s++) {
        res = rowActionScopes(scopes, CFG.sel.stockBtnTexts[s]);
        if (res.ok) break;
      }
      if (!res || !res.ok) {
        if (attempt < 2) { setTimeout(tryOpen, 600); return; }
        send('rap-log', { text: '未找到库存管理按钮' });
        return;
      }
      var waited = 0;
      var poll = setInterval(function () {
        waited += 300;
        var dlg = findStockDialog();
        if (!dlg) {
          var cand = lastVisible(CFG.sel.dialogs);
          if (cand && cand.querySelectorAll('input').length) dlg = cand;
        }
        if (!dlg) { if (waited >= 2400) { clearInterval(poll); send('rap-log', { text: '未检测到库存弹窗，请重试或手动修改' }); } return; }
        clearInterval(poll);
        cb(dlg);
      }, 300);
    }
    tryOpen();
  }

  function findConfirmButton(root, requireVisible) {
    var btns = root.querySelectorAll('button');
    var fallback = null;
    for (var i = 0; i < btns.length; i++) {
      if (requireVisible && !visible(btns[i])) continue;
      var t = (btns[i].textContent || '').trim();
      if (t === '确定' || t === '确认') return btns[i];
      if (!fallback) {
        for (var c = 0; c < CFG.sel.confirmBtnTexts.length; c++) {
          if (t === CFG.sel.confirmBtnTexts[c] || (t.length <= 6 && t.indexOf(CFG.sel.confirmBtnTexts[c]) === 0)) { fallback = btns[i]; break; }
        }
      }
    }
    return fallback;
  }

  function confirmAndClose(dlg, label, then) {
    var btn = findConfirmButton(dlg, false);
    var el = dlg;
    for (var up = 0; up < 6 && el && !btn; up++) { el = el.parentElement; if (el) btn = findConfirmButton(el, false); }
    if (!btn) btn = findConfirmButton(document, true);
    var done = false;
    if (btn) { try { btn.click(); done = true; } catch (e) { } }
    send('rap-log', { text: '库存' + label + '已提交' + (done ? '（已点确定）' : '，未找到确认按钮请手动确认') });
    setTimeout(function () { closeStockDialog(); if (then) then(); }, 600);
  }

  /* 读取商品行的库存信息（不打开弹窗） */
  function rowStockInfo(row) {
    var txt = (row.textContent || '').replace(/\s+/g, ' ');
    var sm = txt.match(/([\d.]+万?)\s*\/\s*([\d.]+万?)/);
    var st = row.querySelector(CFG.sel.rowStatus);
    return { stock: sm ? parseWan(sm[2]) : -1, status: st ? (st.textContent || '').trim() : '' };
  }

  /* 设置后校验：重抓左侧商品行对比库存变化，不重开库存管理 */
  function postCheck(row, msg) {
    setTimeout(function () {
      try {
        var rows2 = getRows();
        var row2 = null;
        if (msg.id) {
          for (var r = 0; r < rows2.length; r++) {
            if ((rows2[r].textContent || '').indexOf(String(msg.id)) >= 0) { row2 = rows2[r]; break; }
          }
        }
        if (!row2 && typeof msg.index === 'number') row2 = rows2[msg.index];
        var post = row2 ? rowStockInfo(row2) : null;
        send('sync-products', { items: scrapeProducts() });
        var pre = msg.pre || null;
        var preV = pre && pre.stock >= 0 ? pre.stock : '?';
        var postV = post && post.stock >= 0 ? post.stock : '?';
        var changed = post && pre && post.stock >= 0 && post.stock !== pre.stock;
        var okZero = msg.mode === 'zero' && post && post.stock === 0;
        send('rap-log', { text: '校验：库存 ' + preV + ' → ' + postV + (post && (changed || okZero) ? '（已更新）' : '（未变化，请检查）') });
      } catch (e) { }
    }, 1500);
  }

  function findRowByIdOrIndex(rows, msg) {
    if (msg.id) {
      for (var r = 0; r < rows.length; r++) {
        var el = rows[r];
        if ((el.getAttribute && el.getAttribute('data-rbd-draggable-id') === String(msg.id)) || (el.textContent || '').indexOf(String(msg.id)) >= 0) return el;
      }
    }
    if (typeof msg.index === 'number' && msg.index >= 0 && msg.index < rows.length) return rows[msg.index];
    return null;
  }

  function stockOp(msg) {
    try {
      var rows = getRows();
      var row = findRowByIdOrIndex(rows, msg);
      if (!row) return { ok: false, msg: '行不存在' };
      var scopes = rowScopes(row);
      var mode = msg.mode || 'zero';
      var label = (mode === 'zero') ? '清零' : (mode === 'plus1' ? '设为1' : '加满');
      msg.pre = rowStockInfo(row);
      openStockDialog(scopes, function (dlg) {
        var batch = dlg.querySelector('input[placeholder*="批量上架数量"]');
        var nums = collectNums(dlg);
        if (batch) nums = nums.filter(function (el) { return el !== batch; });
        if (mode === 'zero' || mode === 'plus1') {
          /* 批量设置：清零=0，加1=每个SKU设为1 */
          var val = (mode === 'zero') ? '0' : '1';
          if (batch) {
            setNativeValue(batch, val);
            clickButtonByText(dlg, '批量填充');
            setTimeout(function () { confirmAndClose(dlg, label, function () { postCheck(row, msg); }); }, 400);
          } else {
            if (!nums.length) { send('rap-log', { text: '未找到数量输入框，请手动修改' }); return; }
            for (var x = 0; x < nums.length; x++) setNativeValue(nums[x], val);
            confirmAndClose(dlg, label, function () { postCheck(row, msg); });
          }
        } else {
          /* 加满：直接点官方“全部填充”（自动填到各SKU剩余专属库存上限）+ 确定 */
          if (clickButtonByText(dlg, '全部填充')) {
            setTimeout(function () { confirmAndClose(dlg, label, function () { postCheck(row, msg); }); }, 400);
          } else {
            send('rap-log', { text: '未找到全部填充按钮，请手动修改' });
          }
        }
      });
      return { ok: true };
    } catch (e) { return { ok: false, msg: String(e) }; }
  }

  function closeStockDialog() {
    try {
      var dlg = findStockDialog() || lastVisible(CFG.sel.dialogs);
      if (!dlg) return;
      var closeEl = dlg.querySelector('[class*="close" i], [aria-label*="关闭"], [aria-label*="Close"]');
      if (closeEl) { try { closeEl.click(); } catch (e) { } return; }
      clickButtonByText(dlg, '取消');
    } catch (e) { }
  }

  function readSkus(msg) {
    try {
      var rows = getRows();
      var row = findRowByIdOrIndex(rows, msg);
      if (!row) return { ok: false, msg: '行不存在' };
      var scopes = rowScopes(row);
      openStockDialog(scopes, function (dlg) {
        send('sku-info', { index: msg.index, skus: readSkuList(dlg) });
        setTimeout(closeStockDialog, 300);
      });
      return { ok: true };
    } catch (e) { return { ok: false, msg: String(e) }; }
  }

  /* ================= 诊断 ================= */
  function diag() {
    try {
      var docs = allRootDocuments(2);
      var info = { url: location.href, title: document.title, iframes: docs.length - 1, login: false, buttons: {}, inputs: [], sections: {}, rows: 0, liveState: liveStateNow() };
      for (var d = 0; d < docs.length; d++) {
        if (docs[d].querySelector('input[type="password"]')) info.login = true;
      }
      var rows = getRows();
      info.rows = rows.length;
      if (rows[0]) info.rowHtml = rows[0].outerHTML.replace(/\s+/g, ' ').slice(0, 3000);
      var texts = {};
      var inps = [];
      for (var d2 = 0; d2 < docs.length; d2++) {
        var doc = docs[d2];
        var els = [];
        try { els = Array.prototype.slice.call(doc.querySelectorAll('button, [role="button"], a')); } catch (e) { }
        for (var i = 0; i < els.length; i++) {
          var t = (els[i].textContent || '').trim();
          if (t && t.length <= 10) texts[t] = (texts[t] || 0) + 1;
        }
        try { inps = inps.concat(Array.prototype.slice.call(doc.querySelectorAll('textarea, input[type="text"], [contenteditable="true"]'))); } catch (e) { }
      }
      info.btnTexts = Object.keys(texts).slice(0, 100);
      for (var j = 0; j < Math.min(inps.length, 10); j++) {
        info.inputs.push({
          tag: inps[j].tagName,
          ph: inps[j].getAttribute ? (inps[j].getAttribute('placeholder') || '') : '',
          cls: String(inps[j].className || '').slice(0, 120),
          iframe: inps[j].ownerDocument !== document
        });
      }
      send('diag-report', info);
    } catch (e) { send('diag-report', { error: String(e) }); }
  }

  /* ================= 公屏监听（自动回复用） ================= */
  /* 定时扫描公屏消息行，解析「昵称：内容」后上报面板；seen 缓存防重复上报 */
  var chatWatch = { timer: null, seen: {}, order: [], warm: 1 };
  function parseChatLine(t) {
    t = (t || '').replace(/\s+/g, ' ').trim();
    if (!t || t.length < 2 || t.length > 120) return null;
    /* 系统消息/状态文字过滤 */
    if (/进入了直播间|欢迎来到|正在直播|直播已结束|本场直播|已下播|直播结束/.test(t)) return null;
    /* 自己发出的自动回复不回解析 */
    if (/回复\s*@/.test(t)) return null;
    var mi = t.indexOf('：');
    if (mi < 0) mi = t.indexOf(':');
    if (mi <= 0 || mi > 25) return null;
    var name = t.slice(0, mi).trim();
    var text = t.slice(mi + 1).trim();
    if (!name || !text || /^[·•\-—|]$/.test(name)) return null;
    return { name: name.slice(0, 20), text: text.slice(0, 100) };
  }
  function findChatContainers() {
    var sels = CFG.sel.commentLists.concat(['[class*="danmu" i]', '[class*="barrage" i]']).join(',');
    var els = qaAll(sels, 2);
    var out = [];
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (!visible(el)) continue;
      var txt = '';
      try { txt = el.innerText || el.textContent || ''; } catch (e) { }
      /* 容器内至少出现两处冒号才像公屏，避免误匹配其它列表 */
      if ((txt.match(/[:：]/g) || []).length >= 2) out.push(el);
    }
    return out;
  }
  function scanChat() {
    try {
      var boxes = findChatContainers();
      var report = chatWatch.warm <= 0; /* 前两轮只记录历史消息不上报，避免把开播前的旧问题都回一遍 */
      for (var b = 0; b < boxes.length; b++) {
        var lines = [];
        try { lines = (boxes[b].innerText || '').split('\n'); } catch (e) { }
        for (var i = 0; i < lines.length; i++) {
          var m = parseChatLine(lines[i]);
          if (!m) continue;
          var key = m.name + '|' + m.text;
          if (chatWatch.seen[key]) continue;
          chatWatch.seen[key] = true;
          chatWatch.order.push(key);
          if (chatWatch.order.length > 300) delete chatWatch.seen[chatWatch.order.shift()];
          if (report) send('viewer-chat', m);
        }
      }
      if (chatWatch.warm > 0) chatWatch.warm--;
    } catch (e) { }
  }
  function startChatWatch() {
    if (chatWatch.timer) return;
    scanChat();
    chatWatch.timer = setInterval(scanChat, 2000);
  }

  /* ================= 宿主消息分发 ================= */
  /* 直播状态判定：唯一信号 = 商品列表行内有无"讲解/取消讲解"按钮
   * 有 → live；开播过（seenLive）后按钮消失 → ended；从未见过 → unknown。
   * 去抖：live 状态下需连续 3 次扫描都看不到按钮才判 ended ——
   * iframe 重载/虚拟滚动重渲染会造成按钮瞬时不可见，单次即判会把自动任务误停掉。 */
  function rawLiveState() {
    try {
      var rows = getRows();
      for (var r = 0; r < rows.length; r++) {
        var scopes = rowScopes(rows[r]);
        var rowBtns = scopesQuery(scopes, 'button, [role="button"]');
        for (var b = 0; b < rowBtns.length; b++) {
          var bt = (rowBtns[b].textContent || '').trim();
          if (bt === '讲解' || bt === '取消讲解') {
            liveWatch.seenLive = true;
            return 'live';
          }
        }
      }
      if (liveWatch.seenLive) return 'ended';
      return 'unknown';
    } catch (e) { return 'unknown'; }
  }
  function liveStateNow() {
    var st = rawLiveState();
    if (st === 'live') {
      if (liveWatch.stable === 'live' && liveWatch.miss > 0) send('rap-log', { text: '直播状态波动已恢复，误判下播已拦截' });
      liveWatch.miss = 0; liveWatch.stable = 'live';
      return 'live';
    }
    if (liveWatch.stable !== 'live') { liveWatch.stable = st; return st; }
    /* 当前稳定状态是 live：容忍瞬时丢失 */
    liveWatch.miss++;
    if (liveWatch.miss >= 3) { liveWatch.stable = 'ended'; liveWatch.miss = 0; return 'ended'; }
    return 'live';
  }
  function liveEndedNow() { return liveStateNow() === 'ended'; }
  window.__rapDispatch = function (msg) {
    if (!msg || !msg.action) return;
    /* 直播状态门控：只拦“自动”动作（自动弹窗周期、自动发评），手动弹窗（popProduct）不受限 */
    if ((msg.action === 'sendComment' || msg.action === 'popCycle') && liveEndedNow()) {
      if (!liveWatch.reported) {
        liveWatch.reported = true;
        send('live-end', { url: location.href, by: 'action' });
      }
      send('rap-log', { text: '直播已结束，' + (msg.action === 'popCycle' ? '自动弹窗' : '自动发评') + '动作已拦截' });
      return;
    }
    var res;
    if (msg.action === 'sendComment') res = sendComment(msg.text || '');
    else if (msg.action === 'popProduct') res = popProduct(msg);
    else if (msg.action === 'popCycle') res = popCycle(msg);
    else if (msg.action === 'ping') res = { ok: true };
    else if (msg.action === 'scrape') { send('sync-products', { items: scrapeProducts() }); res = { ok: true }; }
    else if (msg.action === 'setSync') { setSync(!!msg.on, msg.interval); res = { ok: true }; }
    else if (msg.action === 'clickRowAction') {
      var rr = findRowByIdOrIndex(getRows(), msg);
      res = rr ? rowActionScopes(rowScopes(rr), msg.text) : { ok: false, msg: '行不存在' };
      if (res && res.ok && msg.text === '预热') confirmPreheat();
    }
    else if (msg.action === 'stockOp') res = stockOp(msg);
    else if (msg.action === 'readSkus') res = readSkus(msg);
    else if (msg.action === 'diag') { diag(); res = { ok: true }; }
    if (res && res.ok === false) send('rap-log', { text: (msg.action || '') + ' 失败: ' + (res.msg || '') });
  };

  /* ================= 直播状态检测（上报面板：预启动/自动停止/开播自动运行） ================= */
  var liveWatch = { reported: false, timer: null, last: '', seenLive: false, miss: 0, stable: 'unknown' };
  function checkLive() {
    var st = liveStateNow();
    /* 状态变化即上报（含注入后的首次上报），面板据此启动预挂起的引擎 */
    if (st !== liveWatch.last) {
      liveWatch.last = st;
      send('live-state', { state: st, url: location.href });
    }
    if (st === 'ended') {
      if (!liveWatch.reported) { liveWatch.reported = true; send('live-end', { url: location.href }); }
    } else if (st === 'live') {
      liveWatch.reported = false; /* 直播中：重置，下次下播可再上报 */
    }
  }
  function startLiveWatch() {
    if (liveWatch.timer) { clearInterval(liveWatch.timer); liveWatch.timer = null; }
    checkLive();
    liveWatch.timer = setInterval(checkLive, 3000);
  }

  window.__rap = { version: 5, dispatch: window.__rapDispatch };

  setTimeout(startLiveWatch, 2000);
  setTimeout(startChatWatch, 2500);

  send('rap-ready', { installed: true });
})();
