/* 控制台页 preload：页面 → 宿主 单向桥 */
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('rapBridge', {
  send: function (obj) { try { ipcRenderer.send('tab-msg', obj); } catch (e) { } }
});
